package com.example.islam.eventfinder.datamodel

data class Response(
        val city: City,
        val events: List<Event>
)