package com.example.islam.eventfinder.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.islam.eventfinder.datamodel.Event
import io.reactivex.Flowable

@Dao
interface EventDao {
    @Insert
    fun insertEvent(vararg event: Event)
    @Query ("DELETE FROM event_table")
    fun deleteAllEvents():Int
    @Query ("SELECT * FROM event_table WHERE id= :event_id")
    fun getEventById(event_id: Int):Flowable<List<Event>>
    @Query ("SELECT * FROM event_table")
    fun getAllEvents():Flowable<List<Event>>
}