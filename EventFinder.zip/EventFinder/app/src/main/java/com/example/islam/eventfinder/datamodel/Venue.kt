package com.example.islam.eventfinder.datamodel

data class Venue(
        val id: Int,
        val name: String,
        val lat: Double,
        val lon: Double,
        val repinned: Boolean,
        val address_1: String,
        val city: String,
        val country: String,
        val localized_country_name: String
)