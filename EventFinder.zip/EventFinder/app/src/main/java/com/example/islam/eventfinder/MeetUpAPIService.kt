package com.example.islam.eventfinder

import com.example.islam.eventfinder.datamodel.Response
import io.reactivex.Observable
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface MeetUpAPIService {
    @GET("upcoming_events")
    fun findEvents(@Query("key") key:String,
                   @Query("photo-host") photoHost: String,
                   @Query("page") page: Int,
                   @Query("sign") sign: String): Observable<Response>


    companion object {
        fun create(): MeetUpAPIService{
            val retrofit= Retrofit.Builder()
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl("api.openweathermap.org/data/2.5/")
                    .build()
            return retrofit.create(MeetUpAPIService::class.java)

        }
    }
}