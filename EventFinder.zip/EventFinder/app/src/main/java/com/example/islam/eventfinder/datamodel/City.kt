package com.example.islam.eventfinder.datamodel

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "city_table")
data class City(
        @PrimaryKey
        val id: Int,
        val city: String,
        val lat: Double,
        val lon: Double,
        val state: String,
        val country: String,
        val zip: String,
        val member_count: Int
)