package com.example.islam.eventfinder.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.islam.eventfinder.datamodel.City
import io.reactivex.Flowable
import io.reactivex.Observable

@Dao
interface CityDao {

    @Insert
    fun insertCity(city: City)
    @Query("Delete FROM city_table")
    fun deleteAllCities():Int
    @Query ("SELECT * FROM city_table WHERE id=:city_id")
    fun getCityById(city_id: Int):Flowable<List<City>>
    @Query ("SELECT * FROM city_table")
    fun getAllCities():Flowable<List<City>>

}