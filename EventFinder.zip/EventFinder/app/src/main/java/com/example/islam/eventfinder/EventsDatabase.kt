package com.example.islam.eventfinder

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.example.islam.eventfinder.dao.CityDao
import com.example.islam.eventfinder.dao.EventDao
import com.example.islam.eventfinder.datamodel.City
import com.example.islam.eventfinder.datamodel.Event

@Database(entities = arrayOf(City::class,Event::class),version = 1)
abstract class EventsDatabase : RoomDatabase() {

    abstract fun cityDao() :CityDao
    abstract fun eventDao() :EventDao
    companion object {
        private var INSTANCE:EventsDatabase? = null
        fun getInstance(context: Context):EventsDatabase?{
            if(INSTANCE == null ){
                synchronized(EventsDatabase::class){
                    INSTANCE=Room.databaseBuilder(context.applicationContext,EventsDatabase::class.java,"events.db").build()
                }
            }
            return INSTANCE
        }
        fun destroyInstance() {
            INSTANCE = null
        }
    }
}