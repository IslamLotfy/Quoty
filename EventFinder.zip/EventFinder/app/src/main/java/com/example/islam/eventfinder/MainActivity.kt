package com.example.islam.eventfinder

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import com.example.islam.eventfinder.dao.CityDao
import com.example.islam.eventfinder.dao.EventDao
import com.example.islam.eventfinder.datamodel.Response
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*

class MainActivity : AppCompatActivity() {
    private var disposable: Disposable? = null

    private var response:Response? = null
    private val meetUpAPIService by lazy {
        MeetUpAPIService.create()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        val eventDatabase:EventsDatabase? = EventsDatabase.getInstance(this)
        val eventDao:EventDao? = eventDatabase?.eventDao()
        val cityDao:CityDao? = eventDatabase?.cityDao()

        text_view.setOnClickListener {  ->
            run {
                cityDao?.getAllCities()?.subscribeOn(Schedulers.io())
                        ?.subscribe({ result ->
                            Log.v("result cities", result.toString())
                        }, { error ->
                            Log.v("error ", error.toString())
                        })
                eventDao?.getAllEvents()?.subscribeOn(Schedulers.io())
                        ?.subscribe({ result ->
                            Log.v("result events", result.toString())
                        }, { error ->
                            Log.v("error ", error.toString())
                        })
            }
        }

        fab.setOnClickListener { view ->
            disposable=meetUpAPIService.findEvents("60337448d523962604841513d717f12", "public" , 40 ,"true")
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe( { result ->
                        response=result

                        Observable.just(eventDao?.insertEvent(response!!.events[0]))
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe()
                        Log.v("result ",result.events.size.toString())
                    }, { error -> Log.v("error ",error.toString())
                            })
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
