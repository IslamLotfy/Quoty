package com.example.islam.eventfinder.datamodel
data class Group(
        val created: Long,
        val name: String,
        val id: Int,
        val join_mode: String,
        val lat: Double,
        val lon: Double,
        val urlname: String,
        val who: String,
        val localized_location: String,
        val state: String,
        val country: String,
        val region: String,
        val timezone: String
)