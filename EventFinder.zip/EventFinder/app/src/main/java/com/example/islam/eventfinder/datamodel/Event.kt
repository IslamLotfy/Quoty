package com.example.islam.eventfinder.datamodel

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "event_table")
data class Event(

        @PrimaryKey
        val id: String,
        val name: String,
        val created: Long,
        val duration: Int,
        val status: String,
        val time: Long,
        val local_date: String,
        val local_time: String,
        val updated: Long,
        val utc_offset: Int,
        val waitlist_count: Int,
        val yes_rsvp_count: Int,

        @Embedded(prefix = "venue_")
        val venue: Venue,
        @Embedded(prefix = "group_")
        val group: Group,
        val link: String,
        val description: String,
        val visibility: String,
        val pro_is_email_shared: Boolean,
        val manual_attendance_count: Int,
        @Embedded(prefix = "fee_")
        val fee: Fee,
        val rsvp_limit: Int,
        val how_to_find_us: String,
        val rsvp_open_offset: String,
        val rsvp_close_offset: String
)