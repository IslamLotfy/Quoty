package com.example.islam.eventfinder.datamodel

data class Fee(
        val accepts: String,
        val amount: Double,
        val currency: String,
        val description: String,
        val label: String,
        val required: Boolean
)